<?php

define('CH','exam_');
define('CDO','');
define('CP','/');
define('CRT',180);
define('CS','xn9dylsl012002');
define('HE','utf-8');
define('PN',20);
define('TIME',time());
define('WP','http://'.$_SERVER['SERVER_NAME'].dirname($_SERVER['SCRIPT_NAME']));

define('DB','exam');
define('DH','localhost');
define('DU','root');
define('DP','root');
define('DTH','x2_');

?>