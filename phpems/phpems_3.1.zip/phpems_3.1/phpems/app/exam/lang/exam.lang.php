<?php
/*
 * Created on 2011-12-5
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
$lang['exam'] = array(
	'questiontype' => array('单选题','多选题','不定项选择题','判断题','单选题',)
);
?>
