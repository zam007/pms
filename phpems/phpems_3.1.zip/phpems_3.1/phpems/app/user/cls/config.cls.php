<?php
/*
 * Created on 2013-5-31
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
class config_user
{
	public $fields = array('userid','username','userpassword','usertruename','useremail','usercoin','userregip','userregtime','usergroupid','usermoduleid');
}
?>
